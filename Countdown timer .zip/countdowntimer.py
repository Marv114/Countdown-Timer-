import time
from tkinter import *
from playsound import playsound
import threading

class CountdownTimer:
    def __init__(self, root):
        self.root = root
        self.root.title("Enhanced Countdown Timer")
        self.root.geometry("300x250")

        # Initialize variables
        self.total_seconds = 0
        self.is_running = False

        # Create input fields for hours, minutes, and seconds
        Label(root, text="Hours:").pack()
        self.entry_hours = Entry(root)
        self.entry_hours.pack()

        Label(root, text="Minutes:").pack()
        self.entry_minutes = Entry(root)
        self.entry_minutes.pack()

        Label(root, text="Seconds:").pack()
        self.entry_seconds = Entry(root)
        self.entry_seconds.pack()

        # Create a label to display the timer
        self.timer_label = Label(root, text="00:00:00", font=("Helvetica", 48))
        self.timer_label.pack()

        # Create buttons for control
        Button(root, text="Start Countdown", command=self.start_timer).pack()
        Button(root, text="Pause", command=self.pause_timer).pack()
        Button(root, text="Reset", command=self.reset_timer).pack()

    def countdown(self):
        while self.total_seconds > 0 and self.is_running:
            hours, remainder = divmod(self.total_seconds, 3600)
            minutes, seconds = divmod(remainder, 60)
            self.timer_label.config(text=f"{hours:02}:{minutes:02}:{seconds:02}")
            time.sleep(1)
            self.total_seconds -= 1
        
        if self.total_seconds == 0 and self.is_running:
            playsound('alarm_sound.mp3')  # Ensure you have an alarm sound file in the same directory

    def start_timer(self):
        try:
            hours = int(self.entry_hours.get())
            minutes = int(self.entry_minutes.get())
            seconds = int(self.entry_seconds.get())
            self.total_seconds = hours * 3600 + minutes * 60 + seconds
            
            if not self.is_running:
                self.is_running = True
                threading.Thread(target=self.countdown).start()
        
        except ValueError:
            self.timer_label.config(text="Invalid Input!")

    def pause_timer(self):
        if self.is_running:
            self.is_running = False

    def reset_timer(self):
        self.is_running = False
        self.total_seconds = 0
        self.timer_label.config(text="00:00:00")
        
# Create the main window and run the application
root = Tk()
countdown_timer = CountdownTimer(root)
root.mainloop()
